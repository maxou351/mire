# Theme MDC Intradef

## 3.1.1.0
- Traduction du message de proposition d'identification par un fournisseur d'identité

## 3.1.0.0
- Mise en conformité par rapport à la charte graphique

## 3.0.0.0 - 2022-03-17
- Adaptation pour RH-SSO 7.5

## 2.1.0 - 2021-04-01
- ajout traduction FR pour certains écrans d'administration