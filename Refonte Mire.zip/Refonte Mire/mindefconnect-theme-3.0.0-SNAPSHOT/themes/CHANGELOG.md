# Theme MDC Intradef

## 3.0.0 - 2021-08-10
- migration keycloak  => RedHat-SSO

## 2.1.0 - 2021-04-01
- ajout traduction FR pour certains écrans d'administration