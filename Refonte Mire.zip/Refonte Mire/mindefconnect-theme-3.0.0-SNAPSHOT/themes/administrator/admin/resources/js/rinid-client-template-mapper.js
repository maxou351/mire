document.addEventListener("DOMContentLoaded", event => {
	console.log("rin_id_mapper");
	const dateFieldId = document.getElementById("kcrin_id.bridge_needed").parentNode.parentNode.onclick = (event) {
		console.log("click " + event)
	};
});
